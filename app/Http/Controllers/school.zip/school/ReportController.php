<?php

namespace App\Http\Controllers\school;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use App\Providers\RouteServiceProvider;
use App\Http\Controllers\Controller;
use Illuminate\Database\Migrations\Migration;
use App\Models\Admission;
use App\Models\AddExcActivities;
use App\Models\Fee_pledge;
use App\Models\Fee_extras;
use App\Models\Fee_arrears;
use App\Models\Fee_waivers;
use App\Models\Exam;
use App\Models\Grading_system;

class ReportController extends Controller
{
    public function StudentHistoryreport(request $request)
    {

    }
    public function AdmissionReport(request $request)
    {
        
    }
    public function ActivitiesReport(request $request)
    {
        
    }
    public function feePaymentSummery(request $request)
    {
        
    }
    public function feeStatus(request $request)
    {
        
    }
    public function feeArrears(request $request)
    {
        
    }
    public function feeExtrassReport(request $request)
    {
        
    }
    public function feeExtrassList(request $request)
    {
        
    }
    public function feePaymentReport(request $request)
    {
        
    }
    public function ExamReport(request $request)
    {
        
    }
    public function jointExamReport(request $request)
    {
        
    }
    public function smsExamsReport(request $request)
    {
        
    }
    public function GradeAnalysis(request $request)
    {
        
    }
    public function expenseSummeryReport(request $request)
    {
        
    }
    public function DetailExpensesReport(request $request)
    {
        
    }
    public function wagsReport(request $request)
    {
        
    }
    public function SchoolAssets(request $request)
    {
        
    }
    public function BookFundReport(request $request)
    {
        
    }

}
