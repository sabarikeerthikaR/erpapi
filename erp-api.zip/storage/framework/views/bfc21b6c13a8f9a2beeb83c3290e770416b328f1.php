Hello <?php echo e($name); ?>,<br><br>

Welcome to ERP.<br><br>
Your registered email <?php echo e($email); ?><br><br>
You password <?php echo e($password); ?><br><br>
Login here <?php echo e($url); ?><br><br>
Thank You,<br>
RICO ERP
<?php /**PATH /home/arulphpd/erp.arulphpdeveloper.com/resources/views/email/welcome.blade.php ENDPATH**/ ?>