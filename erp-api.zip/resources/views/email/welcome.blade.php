Hello {{ $name }},<br><br>

Welcome to ERP.<br><br>
Your registered email {{$email}}<br><br>
You password {{$password}}<br><br>
Login here {{$url}}<br><br>
Thank You,<br>
RICO ERP
