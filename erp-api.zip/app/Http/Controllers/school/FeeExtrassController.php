<?php
namespace App\Http\Controllers\school;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use App\Providers\RouteServiceProvider;
use App\Http\Controllers\Controller;
use Illuminate\Database\Migrations\Migration;
use App\Models\FeeExtrass;

class FeeExtrassController extends Controller
{
    public function storeFeeExtras(request $request)
    {

    }
    public function manageFeeExtras(request $request)
    {

    }
    public function allInvoices(request $request)
    {

    }
    public function generateInvoice(request $request)
    {

    }
    public function viewInvoice(request $request)
    {

    }

}
